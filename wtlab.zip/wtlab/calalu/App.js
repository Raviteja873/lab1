import React, { useState } from "react";
import "./App.css";

export default function App() {
  const [exp, setExp] = useState("");

  const add = (v) => setExp(exp + v);
  const clear = () => setExp("");
  const calc = () => {
    try {
      // eslint-disable-next-line no-eval
      setExp(String(eval(exp)));
    } catch {
      setExp("Err");
    }
  };

  return (
    <div className="box">
      <h3>Calculator</h3>
      <input value={exp} readOnly />
      <div>
        <button onClick={() => add("1")}>1</button>
        <button onClick={() => add("2")}>2</button>
        <button onClick={() => add("3")}>3</button>
        <button onClick={() => add("+")}>+</button><br/>
        <button onClick={() => add("4")}>4</button>
        <button onClick={() => add("5")}>5</button>
        <button onClick={() => add("6")}>6</button>
        <button onClick={() => add("-")}>-</button><br/>
        <button onClick={() => add("7")}>7</button>
        <button onClick={() => add("8")}>8</button>
        <button onClick={() => add("9")}>9</button>
        <button onClick={() => add("*")}>*</button><br/>
        <button onClick={() => add("0")}>0</button>
        <button onClick={() => add("/")}>/</button>
        <button onClick={calc}>=</button>
        <button onClick={clear}>C</button>
      </div>
    </div>
  );
}
